package com.example.register

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
